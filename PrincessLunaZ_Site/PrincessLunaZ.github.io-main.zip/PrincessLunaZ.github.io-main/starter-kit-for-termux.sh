apt install python nodejs wget curl
wget https://raw.githubusercontent.com/gushmazuko/metasploit_in_termux/master/metasploit.sh
chmod +x metasploit.sh
npm install discord.js
pip install discord.py
